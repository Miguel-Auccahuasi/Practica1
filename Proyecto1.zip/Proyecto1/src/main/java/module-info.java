module com.company.proyecto1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.company.proyecto1 to javafx.fxml;
    exports com.company.proyecto1;
}