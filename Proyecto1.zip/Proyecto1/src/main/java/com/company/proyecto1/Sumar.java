package com.company.proyecto1;
//Funcion Sumar
public class Sumar {
    public  static void main(String []args) {
        int a = 1;
        int b = 2;
        int c = 3;
        int resultado_suma = sumar(a, b, c);
        System.out.println(resultado_suma);
    }
    public  static int sumar(int a,int b, int c)
    {return a+b+c;}

}