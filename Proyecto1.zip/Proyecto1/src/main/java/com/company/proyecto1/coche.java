package com.company.proyecto1;

public class coche
{
    public  static void main(String []args)
    {
        coche miCoche = new coche();
        int puerta=10;
        int add=10;
        int puerta_add=miCoche.num_puerta(0,4);
        System.out.println("el nuevo coche tiene "+puerta_add+" puertas");
    }
    public  static int num_puerta(int puerta,int add)
    {return puerta+add;}
}